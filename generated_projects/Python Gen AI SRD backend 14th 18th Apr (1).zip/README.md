# Auto-generated FastAPI project

Run with:
```bash
uvicorn app.main:app --reload
```